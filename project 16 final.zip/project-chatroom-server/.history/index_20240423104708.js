const express = require("express");
const cors = require('cors');

const path = require('path');

const app = express();

const server = express();
server.use(express.json());
server.use(cors());

// Serve static files from the "public" directory
server.use(express.static(path.join(__dirname, "public")));

const secretMessage = "Geheim bericht";

server.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "index.html"));
});

const messages = [
  {
    username: "Admin",
    message: "Welkom bij de chatroom.",
  },
];

server.get("/messages", (_, response) => {
  response.status(200);
  response.type("json");

  console.log(`${getTime()} Berichten aangevraagd`);

  response.send(JSON.stringify(messages));
});

server.post("/send", (request, response) => {
  const newMessage = {
    username: request.body.username,
    message: request.body.message,
  };

  messages.push(newMessage);

  console.log(`${getTime()} Bericht ontvangen - ${newMessage.username}: ${newMessage.message}`);

  response.status(200);
  response.send();
});

// Start the server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server listening on port ${PORT}`);
});

function getTime() {
  const time = new Date();
  return `[${time.getHours().toString().padStart(2, "0")}:${time.getMinutes().toString().padStart(2, "0")}:${time.getSeconds().toString().padStart(2, "0")}]`;
}