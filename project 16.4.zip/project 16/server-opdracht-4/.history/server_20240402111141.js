const express = require("express");
const cors = require('cors');

const server = express();
server.use(express.json());
server.use(cors());

const secretMessage = "Geheim bericht";

server.get("/test", (_, response) => {
  console.log("GET Request op /test eindpunt");
  response.status(200);

  const message = "Opdracht 4 Server Online";

  response.send(JSON.stringify({message}));
  console.log(`Response: ${JSON.stringify({message})}`);
});

app.post('/command', (req, res) => {
  const command = req.body;
  
  let response;

  if (command === 'ping') {
    response = 'pong';
  } else {
    response = 'Unknown command';
  }

    if (command ===) "time":
      const time = new Date();
      message = time.getHours() + ":" + time.getMinutes();
      break;

    case "secret":
      message = secretMessage;
      break;

    default:
      message = "Commando niet herkend";
      break;
  }

  response.send(JSON.stringify({ message }));
  console.log(`Response: ${JSON.stringify({ message })}`);
});

server.listen(3000, () => {
  console.log("Server gestart op: http://localhost:3000");
});




  if (command === 'ping') {
    response = 'pong';
  } else {
    response = 'Unknown command';
  }

  console.log(command);

  res.send(response);
});
