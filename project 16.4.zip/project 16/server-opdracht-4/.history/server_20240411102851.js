const express = require("express");
const cors = require("cors");
const path = require("path");

const server = express();
server.use(express.json());
server.use(cors());

// Serve static files from the "public" directory
server.use(express.static(path.join(__dirname, "public")));

const secretMessage = "Geheim bericht";

server.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

server.post("/command", (req, res) => {
  console.log("Received command:", req.body.command);

  let message;

  switch (req.body.command.toLowerCase()) {
    case "ping":
      message = "pong";
      break;

    case "time":
      const time = new Date();
      message = time.getHours() + ":" + time.getMinutes();
      break;

    case "secret":
      message = secretMessage;
      break;

    default:
      message = "Command not recognized";
      break;
  }

  res.json({ message });
});

server.listen(3000, () => {
  console.log("Server listening on port 3000");
});




























// const express = require("express");
// const cors = require('cors');

// const server = express();
// server.use(express.json());
// server.use(express.urlencoded({ extended: true }));

// const secretMessage = "Geheim bericht";

// server.get("/test", (_, response) => {
//   console.log("GET Request op /test eindpunt");
//   response.status(200);

//   const message = "Opdracht 4 Server Online";

//   response.send(JSON.stringify({message}));
//   console.log(`Response: ${JSON.stringify({message})}`);
// });

// server.post("/command", (request, response) => {
//   console.log("Received command:", request.body.command);

//   let message;

//   switch (request.body.command.toLowerCase()) {
//     case "ping":
//       message = "pong";
//       break;

//     case "time":
//       const time = new Date();
//       message = time.getHours() + ":" + time.getMinutes();
//       break;

//     case "secret":
//       message = secretMessage;
//       break;

//     default:
//       message = "Command not recognized";
//       break;
//   }
//   response.json({ message });
// });


// server.listen(3000);

