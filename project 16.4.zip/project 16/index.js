// const chatlog = [];

// function newMsg() {
//   const newMessage = document.querySelector('#msgbox').value;
//   chatlog.push(newMessage);

//   document.querySelector('#msgbox').value = '';

//   const li = document.createElement('li');
//   li.innerText = newMessage;
//   document.getElementById("chatlog").appendChild(li); 
// }

// function renderChatLog() {
//   const list = document.getElementById("chatlog");
  
//   for (let i = 0; i < chatlog.length; i++) {
//     const li = document.createElement('li');
//     li.innerText = chatlog[i];
//     list.appendChild(li);
//   }
// }



const serverAddress = "http://localhost:3000";

fetch(serverAddress + "/test", { method: "GET" })
 .then((response) => response.json())
 .then((json) =>{
  document.querySelector("#serverStatus").innertext = json.message;
 })
 .catch((err) => {
  document.querySelector("#serverStatus").innertext = err.message;
 });

 fetch(serverAddress + "/command", { 
  method: "POST",
  headers: {"content-type": "application/json"},
  body: JSON.stringify(request),
 })

 function sendCommand() {
  const command = document.querySelector("#inputCommand").value;
  const request = { command: command };
 }